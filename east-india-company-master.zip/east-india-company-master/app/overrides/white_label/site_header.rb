Deface::Override.new(:virtual_path => "spree/shared/_header",
                     :replace      => "#spree-header",
                     :name         => "site_header",
                     :partial      => "white_label/shared/header",
                     :original     => '92c159ac9d2aec631cbdbd556c82b361923d63c5')
