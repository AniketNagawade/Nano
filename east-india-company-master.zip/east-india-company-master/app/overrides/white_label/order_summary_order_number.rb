Deface::Override.new(:virtual_path => "spree/orders/show",
                     :remove       => "#order_summary legend",
                     :name         => "order_summary_order_number",
                     :original     => '26e15e72b3f2b0ba42f96fd9da800211ac319a40')
