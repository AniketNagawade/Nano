Deface::Override.new(:virtual_path => "spree/shared/_nav_bar",
                     :replace      => "#top-nav-bar",
                     :name         => "top_nav_bar",
                     :partial      => "white_label/shared/top_nav_bar",
                     :original     => '220e8fbb68796393342aa238ed83abfdd1083710')
