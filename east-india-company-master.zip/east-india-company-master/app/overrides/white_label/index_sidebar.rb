Deface::Override.new(:virtual_path => "spree/home/index",
                     :remove       => "[data-hook='homepage_sidebar_navigation']",
                     :name         => "remove_index_sidebar",
                     :original     => 'd9a21ccc62b9787b5b2f24d6baf226dba776e4a3')
